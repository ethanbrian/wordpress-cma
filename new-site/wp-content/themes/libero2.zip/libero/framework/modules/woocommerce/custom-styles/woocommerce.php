<?php
/**
 * Custom styles for Counter shortcode
 * Hooks to libero_mikado_style_dynamic hook
 */

//if (!function_exists('libero_mikado_counter_style')) {
//
//	function libero_mikado_counter_style()
//	{
//
//		if (libero_mikado_options()->getOptionValue('option_value') !== '') {
//			echo libero_mikado_dynamic_css('.css-class', array(
//				//Css rules, etc
//				'height' => libero_mikado_filter_px(libero_mikado_options()->getOptionValue('option_value')) . 'px'
//			));
//		}
//
//	}
//
//	add_action('libero_mikado_style_dynamic', 'libero_mikado_counter_style');
//
//}

?>