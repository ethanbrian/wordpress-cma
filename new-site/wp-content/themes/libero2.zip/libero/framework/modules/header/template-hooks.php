<?php

//mobile header
add_action('libero_mikado_after_page_header', 'libero_mikado_get_mobile_header');