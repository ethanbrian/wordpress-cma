<?php

get_header();
libero_mikado_get_title();
get_template_part('slider');
libero_mikado_single_portfolio();
get_footer();

?>