<div class="clearfix">
	<div class="mkd_column mkd-column1">
		<div class="mkd-column-inner">
			<?php if(is_active_sidebar('footer_column_1')) {
				dynamic_sidebar( 'footer_column_1' );
			} ?>
		</div>
	</div>
</div>