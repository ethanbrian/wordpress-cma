<div class="mkd-single-tags-holder">
	<span class="mkd-single-tags-icon icon-tag"></span>
	<h4 class="mkd-single-tags-title"><?php esc_html_e('Tags:', 'libero'); ?></h4>
	<div class="mkd-tags">
		<?php the_tags('', '', ''); ?>
	</div>
</div>