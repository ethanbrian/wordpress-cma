<div class="mkd-post-info-comments-holder">
	<a class="mkd-post-info-comments" href="<?php comments_link(); ?>" target="_self">
		<span class="mkd-post-info-comments-no"><?php comments_number('0', '1', '%'); ?></span>
		<span class="mkd-post-info-comments-text"><?php comments_number(esc_html__('Comments','libero'),esc_html__('Comment','libero'),esc_html__('Comments','libero') ); ?></span>
	</a>
</div>