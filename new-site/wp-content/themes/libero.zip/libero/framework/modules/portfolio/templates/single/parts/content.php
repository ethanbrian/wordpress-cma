<div class="mkd-portfolio-info-item">
    <h4><?php the_title(); ?></h4>
    <div class="mkd-portfolio-content">
        <?php the_content(); ?>
    </div>
</div>