<?php

require_once MIKADO_CORE_ABS_PATH.'/shortcodes/fullwidth-slider/fullwidth-slider-holder.php';
require_once MIKADO_CORE_ABS_PATH.'/shortcodes/fullwidth-slider/fullwidth-slider-item.php';