<?php
require_once MIKADO_CORE_ABS_PATH.'/shortcodes/tabs/tabs.php';
require_once MIKADO_CORE_ABS_PATH.'/shortcodes/tabs/tab.php';
require_once MIKADO_CORE_ABS_PATH.'/shortcodes/tabs/custom-styles/custom-styles.php';
require_once MIKADO_CORE_ABS_PATH.'/shortcodes/tabs/options-map/map.php';
