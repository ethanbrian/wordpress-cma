<?php
define('MIKADO_INSTAGRAM_FEED_VERSION', '2.0');
define('MIKADO_INSTAGRAM_ABS_PATH', dirname(__FILE__));
define('MIKADO_INSTAGRAM_REL_PATH', dirname(plugin_basename(__FILE__ )));